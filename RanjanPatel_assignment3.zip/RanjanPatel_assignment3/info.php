<!doctype html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>index Page</title>
    <style>
    .error{
        color:red;
    }
    body{
        margin:50px 350px 350px ;
        padding:10px 150px;
        border :2px solid black;

    }
    .button{
        background-color: #4CAF50; /* Green */
        border: none;
        color: white;
        text-align: center;
        text-decoration: none;
        display: inline-block;
        font-size: 16px;
        margin: 4px 2px;
        cursor: pointer;
        padding:10px;
        margin-left:100px;

    }
    </style>
</head>
<body>
<?php
//**********Ranjan Patel 8622791 ********************************************/
require("submit.php");

?>

<form  action="" method="POST">
	<p>Username: <input type="text" name="username" size="30" maxlength="60" value="<?php if(isset($username)) echo $username;?>">
    <snap class="error"><?php if(isset($errname)){echo $errname;} ?>*</snap>
    </p>
    <p>Age: <input type="number" name="age" size="30" maxlength="60" value="<?php if(isset($age)) echo $age;?>">
    <snap class="error"><?php if(isset($errage)){echo $errage;} ?>*</snap>
    </p>
	<p>Password: <input type="text" name="password" size="30" maxlength="80" value="<?php if(isset($password)) echo $password;?>">
    <snap class="error"><?php if(isset($errpwd)){echo $errpwd;} ?>*</snap>
    </p>
    <p>city: <input type="text" name="city" size="30" maxlength="60" value="<?php if(isset($city)) echo $city;?>">
    <snap class="error"><?php if(isset($errcity)){echo $errcity;} ?>*</snap>
    </p>
    <p>country: <input type="text" name="country" size="30" maxlength="60" value="<?php if(isset($country)) echo $country;?>">
    <snap class="error"><?php if(isset($errcountry)){echo $errcountry;} ?>*</snap>
    </p>

	<p ><input type="submit" name="submit" value="Send" class = "button"></p>
</form>

</body>
</html>