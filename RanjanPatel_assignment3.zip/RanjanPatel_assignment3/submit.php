<?php
//**********Ranjan Patel 8622791 ********************************************/


if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    $username = $age = $password = $city = $country ='';
    $username = strip_tags($_POST['username']); //using strip_tags to remove any kind of tags in input field
    $age = strip_tags($_POST['age']);
    $password= strip_tags($_POST['password']);
    $city = strip_tags($_POST['city']);
    $country = strip_tags($_POST['country']);
    $errname = $errage = $errpwd =$errcity = $errcountry = '';
    if(empty($username)){ // using empty function for all fields to check input box is empty or it has value
        $errname = "Please entry username"; // if input box has no value will display this message
    }
    else{
        $usernameF = $username;
    }
    if(empty($age)){
       $errage = 'Please entry age';
    }
    else{
        
            if (filter_var($age, FILTER_VALIDATE_INT) >= 18 && filter_var($age, FILTER_VALIDATE_INT) <=120) { // condition that check age is between 18 -120
                $ageF = $age;
            }
            else{
                $errage = 'Age should be number and between 18-120'; // if not message will display to user
            }

    }
    if(empty($password)){
        $errpwd = 'Please entry password';
    }  
    else{
        if(preg_match('^(?=.*[A-Za-z])(?=.*[@$!%*#?&])[A-Za-z\d@$!%*#?&]{6,}$^',$password)){ // checking password pattern that says password should be longer than 6 characters and should have special characters
            $passwordF = $password;
        }
        else
        {
            $errpwd = 'Password should be 6 characters longer and shold have special character,numbers in it';// if not message wll display
        }
    }
    if(empty($city)){
       $errcity = 'Please entry city';
    } 
    else{
        $cityF = $city;
    }
    if(empty($country)){
        $errcountry = 'Please entry country';
    }
    else{
        $countryF = $country;
    }
    
    if(isset($usernameF) && isset($ageF) && isset($passwordF) && isset($cityF) && isset($countryF)){ // if everythings are checked will dispaly success message
        
       
        echo "<b><p style = 'color:Green'>**************Success********************</b>";
    }

}






?>