<!doctype html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>index Page</title>
    <style>
    .error{
        color:red;
    }
    body{
        margin:50px 350px 350px ;
        padding:10px 150px;
        border :2px solid black;

    }
    .button{
        background-color: #4CAF50; /* Green */
        border: none;
        color: white;
        text-align: center;
        text-decoration: none;
        display: inline-block;
        font-size: 16px;
        margin: 4px 2px;
        cursor: pointer;
        padding:10px;
        margin-left:100px;

    }
    </style>
</head>
<body>
<?php
//**********Ranjan Patel 8622791 ********************************************/
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $strtn = $errstrptn = '';
    $strptn = $_POST['strptn'];
   
    
        if(preg_match('/^[\w]{2,10}(-|\.)[\w]{2,4}\.[\w]{2,10}[-][\w]{3,8}$/',$strptn)){
            echo '<b><p style = "color:Green">its  string is correct</p></b>';
        }
        else{
            $errstrptn = 'Sorry not match';
        }
  
   
}

?>

<form  action="" method="POST">
	<p>enter any string: <input type="text" name="strptn" size="30" maxlength="60" value="<?php if(isset($strptn)) echo $strptn;?>">
    <snap class="error"><?php if(isset($errstrptn)){echo $errstrptn;} ?>*</snap>
    </p>

	<p ><input type="submit" name="submit" value="Send" class = "button"></p>
</form>

</body>
</html>