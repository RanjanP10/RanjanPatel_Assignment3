<!doctype html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>index Page</title>
    <style>
    .error{
        color:red;
    }
    body{
        margin:50px 350px 350px ;
        padding:10px 150px;
        border :2px solid black;

    }
    .button{
        background-color: #4CAF50; /* Green */
        border: none;
        color: white;
        text-align: center;
        text-decoration: none;
        display: inline-block;
        font-size: 16px;
        margin: 4px 2px;
        cursor: pointer;
        padding:10px;
        margin-left:100px;

    }
    </style>
</head>
<body>
<?php
//**********Ranjan Patel 8622791 ********************************************/
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $hexa = $errhexa = '';
    $hexa = $_POST['hexa'];
    if(strlen($hexa) == 2) // characters lenth checking should be 2 characters only
    {
        if(preg_match('^[0-9A-F]+$^',$hexa)){ // pattern checking
            echo '<b><p style = "color:Green">its hexadecimal number</p></b>';
        }
        else{
            $errhexa = 'not a hexadecimal number........';
        }
    }
    else{
        $errhexa = 'please enter two characters only...';
    }
   
}

?>

<form  action="" method="POST">
	<p>enter any 2 characters: <input type="text" name="hexa" size="30" maxlength="60" value="<?php if(isset($hexa)) echo $hexa;?>">
    <snap class="error"><?php if(isset($errhexa)){echo $errhexa;} ?>*</snap>
    </p>

	<p ><input type="submit" name="submit" value="Send" class = "button"></p>
</form>

</body>
</html>